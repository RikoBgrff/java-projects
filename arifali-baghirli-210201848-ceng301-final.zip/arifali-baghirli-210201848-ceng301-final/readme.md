I've been interested in software for more than 5 years and I've been working professionally as a full stack .NET developer for more than 2 years. So I'm not satisfied with just one project, I choose and write several projects from the list as I have time. If you only accept one, please choose the Notepad or the Calculator project. If you are interested in my projects I leave my GitHub and Linkedin accounts below. I keep most of my work in a private repository, but if you want to see it, I can send you an invitation.Thanks,have a great day!

-notes-
--start of notes--
--all projects have unique source code,documentation and media folders.
--all projects have screenshots/videos,documentation files.
--chatgpt used for only prettify documentation texts.
--all documentation files has written by myself.
--end of notes--
-notes-

-sources-
--start of sources--
--stackoverflow
--used for support external features (notepad app)
--end of sources--
-sources-

github:https://github.com/RikoBgrff

linkedin:https://www.linkedin.com/in/rikobgrff/

student mail: 210201848@ostimteknik.edu.tr
personal mail: riko.bagirli777@gmail.com

sincerely,Arifali Baghirli - 210201848 
