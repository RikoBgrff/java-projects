public class CalculatorLogic {
    public static String evaluateExpression(String expression) {
        try {
            return String.valueOf(new javax.script.ScriptEngineManager().getEngineByName("JavaScript").eval(expression));
        } catch (javax.script.ScriptException e) {
            return "Error";
        }
    }
}
