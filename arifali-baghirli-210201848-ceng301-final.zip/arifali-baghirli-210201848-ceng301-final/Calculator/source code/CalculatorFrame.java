import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorFrame {
    private JFrame frame;
    private JTextField displayField;
    private StringBuilder inputText = new StringBuilder();

    public void initialize() {
        frame = new JFrame("Calculator by rikobgrff");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setSize(400, 600);

        displayField = new JTextField();
        displayField.setHorizontalAlignment(JTextField.RIGHT);
        displayField.setEditable(false);
        displayField.setFont(new Font("Montserrat", Font.PLAIN, 30));
        displayField.setPreferredSize(new Dimension(frame.getWidth(), 100));
        frame.add(displayField, BorderLayout.NORTH);

        JPanel buttonsPanel = new JPanel(new GridLayout(5, 4, 10, 10));
        addButton(buttonsPanel, "7");
        addButton(buttonsPanel, "8");
        addButton(buttonsPanel, "9");
        addButton(buttonsPanel, "/");
        addButton(buttonsPanel, "4");
        addButton(buttonsPanel, "5");
        addButton(buttonsPanel, "6");
        addButton(buttonsPanel, "*");
        addButton(buttonsPanel, "1");
        addButton(buttonsPanel, "2");
        addButton(buttonsPanel, "3");
        addButton(buttonsPanel, "-");
        addButton(buttonsPanel, "0");
        addButton(buttonsPanel, ".");
        addButton(buttonsPanel, "%");
        addButton(buttonsPanel, "+");
        addButton(buttonsPanel, "C");
        addButton(buttonsPanel, "<-");
        addButton(buttonsPanel, "+-");

        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        frame.add(buttonsPanel, BorderLayout.CENTER);

        JButton equalsButton = new JButton("=");
        equalsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateResult();
            }
        });
        equalsButton.setFont(new Font("Montserrat", Font.PLAIN, 30));
        buttonsPanel.add(equalsButton);

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void addButton(Container container, String text) {
        JButton button = new JButton(text);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleButtonClick(text);
            }
        });
        button.setFont(new Font("Arial", Font.PLAIN, 30));
        container.add(button);
    }

    private void handleButtonClick(String buttonText) {
        switch (buttonText) {
            case "C":
                clearDisplay();
                break;
            case "<-":
                backspace();
                break;
            case "+-":
                toggleSign();
                break;
            default:
                inputText.append(buttonText);
                displayField.setText(inputText.toString());
        }
    }

    private void clearDisplay() {
        inputText.setLength(0);
        displayField.setText("");
    }

    private void backspace() {
        if (inputText.length() > 0) {
            inputText.deleteCharAt(inputText.length() - 1);
            displayField.setText(inputText.toString());
        }
    }

    private void toggleSign() {
        if (inputText.length() > 0) {
            char firstChar = inputText.charAt(0);
            if (firstChar == '-') {
                inputText.deleteCharAt(0);
            } else {
                inputText.insert(0, '-');
            }
            displayField.setText(inputText.toString());
        }
    }

    private void calculateResult() {
        try {
            String result = CalculatorLogic.evaluateExpression(inputText.toString());
            displayField.setText(result);
            inputText.setLength(0);
            inputText.append(result);
        } catch (Exception e) {
            displayField.setText("Error");
            inputText.setLength(0);
        }
    }
}
